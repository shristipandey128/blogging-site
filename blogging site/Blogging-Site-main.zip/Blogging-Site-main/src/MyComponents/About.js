import React from 'react'

export const About = () => {
    return (
        <div>
            <p>This website is created by Shraddha verma</p>
        </div>
    )
}
